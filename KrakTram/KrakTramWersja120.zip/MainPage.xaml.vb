﻿' The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

Imports Windows.Data.Json
Imports Windows.Devices.Geolocation
Imports Windows.Web.Http
''' <summary>
''' An empty page that can be used on its own or navigated to within a Frame.
''' </summary>
Public NotInheritable Class MainPage
    Inherits Page
    Private Sub bSetup_Click(sender As Object, e As RoutedEventArgs)
        Me.Frame.Navigate(GetType(Setup))
    End Sub


    Private Sub Page_Loaded(sender As Object, e As RoutedEventArgs)
        App.CheckLoadStopList()
    End Sub

    Private Shared Function VehicleId2VehicleType(sTmp As String) As String
        ' https://github.com/jacekkow/mpk-ttss/blob/master/common.js
        If sTmp.Substring(0, 15) <> "635218529567218" Then Return "???"
        Dim id = CInt(sTmp.Substring(15)) - 736
        If id = 831 Then id = 216
        If id < 100 Then Return "???"

        If id < 200 Then Return "E1"  ' lowfloor=0
        If id < 300 Then Return "105N"  ' lowfloor=0
        If id < 400 Then Return "GT8"  ' lowfloor=0, dla 313 i 323 low=1; 
        If id < 450 Then Return "EU8N"  ' lowfloor=1
        If id < 500 Then Return "N8"  ' lowfloor=1
        If id < 600 Then Return "???"
        If id < 700 Then Return "NGT6"  ' lowfloor=2
        If id < 800 Then Return "???"
        If id < 890 Then Return "NGT8"
        If id = 899 Then Return "126N"
        If id < 990 Then Return "2014N"
        If id = 990 Then Return "405N-Kr"

        Return "???"
    End Function

    Private Async Function GetTablicaHtml(iId As Integer, iOdl As Integer) As Task(Of String)
        Dim oHttp As New HttpClient()
        Dim sTmp As String
        sTmp = Await oHttp.GetStringAsync(New Uri("http://www.ttss.krakow.pl/internetservice/services/passageInfo/stopPassages/stop?mode=departure&stop=" & iId))

        '{
        '  "actual": [
        '    {
        '      "actualRelativeTime": 98,
        '      "actualTime": "10:18",
        '      "direction": "Krowodrza G˘rka",
        '      "mixedTime": "1 Min",
        '      "passageid": "-9223372036596777280",
        '      "patternText": "50",
        '      "plannedTime": "10:17",
        '      "routeId": "6350571212602605631",
        '      "status": "PREDICTED",
        '      "tripId": "6351558574047045895",
        '      "vehicleId": "6352185295672181656"
        '    },
        '        ],
        '"directions": [],
        '"firstPassageTime": 1457685982000,
        '"generalAlerts": [],
        '"lastPassageTime": 1457692680000,
        '        "routes" [
        '  {
        '    "alerts": [],
        '    "authority": "MPK",
        '    "directions": [
        '      "Kurdwan˘w",
        '      "Salwator"
        '    ],
        '    "id": "6350571212602605624",
        '    "name": "6",
        '    "routeType": "tram",
        '    "shortName": "6"
        '  },
        '],
        '"stopName": "Dauna",
        '"stopShortName": "632"

        Dim oJson As JsonObject
        Try
            oJson = JsonObject.Parse(sTmp)
        Catch ex As Exception
            App.DialogBox("ERROR: JSON parsing error - tablica")
            Return ""
        End Try

        Dim oJsonStops As New JsonArray
        Try
            oJsonStops = oJson.GetNamedArray("actual")
        Catch ex As Exception
            App.DialogBox("ERROR: JSON ""actual"" array missing")
            Return ""
        End Try

        If oJsonStops.Count = 0 Then
            App.DialogBox("ERROR: JSON 0 obiektów - tablica")
            Return ""
        End If

        Dim sXml As String = ""

        For Each oVal In oJsonStops
            sXml = sXml & vbCrLf & "<tr>"

            Try
                sTmp = oVal.GetObject.GetNamedString("patternText", "<error>")
            Catch ex As Exception
                sTmp = "<error>"
            End Try
            sXml = sXml & "<td rowspan=2><font size=+2><b>" & sTmp & "</b></font><br>"

            Try
                sTmp = VehicleId2VehicleType(oVal.GetObject.GetNamedString("vehicleId", "<error>"))
            Catch ex As Exception
                sTmp = "<error>"
            End Try
            sXml = sXml & "<font size=-1>" & sTmp & "</font></td>"

            Try
                sTmp = oVal.GetObject.GetNamedString("direction")
            Catch ex As Exception
                sTmp = "<error>"
            End Try
            sXml = sXml & "<td><b>" & sTmp & "</b></td>"

            Try
                sTmp = oVal.GetObject.GetNamedString("mixedTime").Replace("Min", "min")
            Catch ex As Exception
                sTmp = "<error>"
            End Try
            sXml = sXml & "<td rowspan=2><font size=+1>" & sTmp & "</font></td>"
            sXml = sXml & "</tr><tr>"

            Try
                sTmp = oJson.GetObject.GetNamedString("stopName")
            Catch ex As Exception
                sTmp = "<error>"
            End Try
            sXml = sXml & "<td><font size=-1>" & sTmp & " <small>(" & iOdl & ")</small></font></td>"
            sXml = sXml & "</tr>"
        Next

        Return sXml

    End Function
    Private Async Function GetTablicaXml(iId As Integer, iOdl As Integer) As Task(Of String)
        Dim oHttp As New HttpClient()
        Dim sTmp As String
        sTmp = Await oHttp.GetStringAsync(New Uri("http://www.ttss.krakow.pl/internetservice/services/passageInfo/stopPassages/stop?mode=departure&stop=" & iId))

        Dim oJson As JsonObject
        Try
            oJson = JsonObject.Parse(sTmp)
        Catch ex As Exception
            App.DialogBox("ERROR: JSON parsing error - tablica")
            Return ""
        End Try

        Dim oJsonStops As New JsonArray
        Try
            oJsonStops = oJson.GetNamedArray("actual")
        Catch ex As Exception
            App.DialogBox("ERROR: JSON ""actual"" array missing")
            Return ""
        End Try

        If oJsonStops.Count = 0 Then
            App.DialogBox("ERROR: JSON 0 obiektów - tablica")
            Return ""
        End If

        Dim sXml As String = ""

        For Each oVal In oJsonStops
            sXml = sXml & vbCrLf & "<item"

            Try
                sTmp = oVal.GetObject.GetNamedString("patternText")
            Catch ex As Exception
                sTmp = "!error!"
            End Try
            sXml = sXml & " line=""" & sTmp & """ "

            Try
                sTmp = VehicleId2VehicleType(oVal.GetObject.GetNamedString("vehicleId"))
            Catch ex As Exception
                sTmp = "!error!"
            End Try
            sXml = sXml & " typ=""" & sTmp & """ "

            Try
                sTmp = oVal.GetObject.GetNamedString("direction")
            Catch ex As Exception
                sTmp = "!error!"
            End Try
            sXml = sXml & " dir=""" & sTmp & """ "

            Try
                sTmp = oVal.GetObject.GetNamedString("mixedTime").Replace("Min", "min")
            Catch ex As Exception
                sTmp = "!error!"
            End Try
            sXml = sXml & " time=""" & sTmp & """ "

            Try
                sTmp = oJson.GetObject.GetNamedString("stopName")
            Catch ex As Exception
                sTmp = "!error!"
            End Try
            sXml = sXml & " stop=""" & sTmp & """ "
            sXml = sXml & " odl=""" & iOdl & """ "
            sXml = sXml & " />"
        Next

        Return sXml

    End Function

    Private Async Sub bGetGPS_Click(sender As Object, e As RoutedEventArgs)
        Dim iOdl As Integer

        Dim oPoint As Point = Await App.GetCurrentPoint
        Dim sHtml = "<html><body><table border=1>"
        'Dim sHtml = "<?xml-stylesheet type='text/xsl' href='Assets/stylik.xslt'?><root>"

        For Each oNode In App.oStops.SelectNodes("//stop")
            iOdl = App.GPSdistanceDwa(oPoint.X, oPoint.Y, oNode.SelectSingleNode("@lat").NodeValue, oNode.SelectSingleNode("@lon").NodeValue)
            If iOdl < App.GetSettingsInt("maxOdl") Then
                sHtml = sHtml & Await GetTablicaHtml(CInt(oNode.SelectSingleNode("@id").NodeValue), iOdl)
                'sHtml = sHtml & Await GetTablicaXml(CInt(oNode.SelectSingleNode("@id").NodeValue), iOdl)
            End If
        Next

        'sHtml = sHtml & "</table></body></html>"
        sHtml = sHtml & "</root>"
        uiWebView.NavigateToString(sHtml)
    End Sub

    Private Sub Page_Resized(sender As Object, e As SizeChangedEventArgs)
        uiWebView.Height = uiMainGrid.ActualHeight - 50
    End Sub
End Class
