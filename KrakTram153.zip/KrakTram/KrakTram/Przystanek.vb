﻿'Imports System.Net.Http
'Imports System.Net.NetworkInformation
Imports System.Xml.Serialization
'Imports Windows.Data.Json
'Imports Windows.Storage


<XmlType("stop")>
Public Class Przystanek
    <XmlAttribute()>
    Public Property Cat As String
    <XmlAttribute()>
    Public Property Lat As Double
    <XmlAttribute()>
    Public Property Lon As Double
    <XmlAttribute()>
    Public Property Name As String
    <XmlAttribute()>
    Public Property id As String
End Class



Public Class Przystanki
    Private Itemy As Collection(Of Przystanek) = New Collection(Of Przystanek)
    ' Add
    Private Sub Add(sCat As String, dLatTtss As Double, dLonTtss As Double, sName As String, sId As String)
        Dim oNew As Przystanek = New Przystanek
        oNew.Cat = sCat
        oNew.id = sId
        oNew.Name = sName
        oNew.Lat = dLatTtss / 3600000.0
        oNew.Lon = dLonTtss / 3600000.0
        Itemy.Add(oNew) ' błąd resource; dodawanie pustego ("" oraz 0) też powoduje error
    End Sub
    ' Delete
    ' New
    Private Async Function Save() As Task

        Dim oFile As Windows.Storage.StorageFile =
            Await Windows.Storage.ApplicationData.Current.LocalCacheFolder.CreateFileAsync(
                "stops1.xml", Windows.Storage.CreationCollisionOption.ReplaceExisting)

        If oFile Is Nothing Then Exit Function

        Dim oSer As XmlSerializer = New XmlSerializer(GetType(Collection(Of Przystanek)))
        Dim oStream As Stream = Await oFile.OpenStreamForWriteAsync
        oSer.Serialize(oStream, Itemy)
        oStream.Dispose()   ' == fclose
    End Function

    ' Load
    Private Async Function Load() As Task(Of Boolean)
        ' ret=false gdy nie jest wczytane

        Dim oObj As Windows.Storage.StorageFile =
            Await Windows.Storage.ApplicationData.Current.LocalCacheFolder.TryGetItemAsync("stops1.xml")
        If oObj Is Nothing Then Return False
        Dim oFile As Windows.Storage.StorageFile = TryCast(oObj, Windows.Storage.StorageFile)

        Dim oSer As XmlSerializer = New XmlSerializer(GetType(Collection(Of Przystanek)))
        Dim oStream As Stream = Await oFile.OpenStreamForReadAsync
        Itemy = TryCast(oSer.Deserialize(oStream), Collection(Of Przystanek))

        Return True
    End Function

    Private Async Function Import() As Task(Of Boolean)
        ' ret=false gdy nieudane wczytanie z sieci

        If Not Net.NetworkInformation.NetworkInterface.GetIsNetworkAvailable() Then
            App.DialogBoxRes("resErrorNoNetwork")
            Return False
        End If

        Dim oHttp As New System.Net.Http.HttpClient()
        Dim sTmp As String = ""
        oHttp.Timeout = TimeSpan.FromSeconds(10)

        Dim bError As Boolean = False

        Try
            sTmp = Await oHttp.GetStringAsync("http://www.ttss.krakow.pl/internetservice/geoserviceDispatcher/services/stopinfo/stops?left=-648000000&bottom=-324000000&right=648000000&top=324000000")
        Catch ex As Exception
            bError = True
        End Try
        If bError Then
            App.DialogBoxRes("resErrorGetHttp")
            Return False
        End If

        ' {"stops": [
        '{
        '  "category": "tram",
        '  "id": "6350927454370005230",
        '  "latitude": 180367133,
        '  "longitude": 72043450,
        '  "name": "Os.Piastów",
        '  "shortName": "378"
        '},

        If sTmp.IndexOf("""stops""") < 0 Then
            App.DialogBoxRes("resErrorBadTTSSstops")
            Return False
        End If

        Dim oJson As Windows.Data.Json.JsonObject = Nothing
        Try
            oJson = Windows.Data.Json.JsonObject.Parse(sTmp)
        Catch ex As Exception
            bError = True
        End Try
        If bError Then
            App.DialogBox("ERROR: JSON parsing error")
            Return False
        End If

        Dim oJsonStops As New Windows.Data.Json.JsonArray
        Try
            oJsonStops = oJson.GetNamedArray("stops")
        Catch ex As Exception
            bError = True
        End Try
        If bError Then
            App.DialogBox("ERROR: JSON ""stops"" array missing")
            Return False
        End If

        If oJsonStops.Count = 0 Then
            App.DialogBox("ERROR: JSON 0 obiektów")
            Return False
        End If

        ' wszystkie testy juz za nami, to teraz importujemy
        Itemy.Clear()

        Try
            For Each oVal As Windows.Data.Json.IJsonValue In oJsonStops
                Dim sName As String
                Dim sCat As String
                Dim sShortName As String
                sName = oVal.GetObject.GetNamedString("name")
                sCat = oVal.GetObject.GetNamedString("category")
                sShortName = oVal.GetObject.GetNamedString("shortName")
                Dim dLat As Double
                Dim dLon As Double
                dLat = oVal.GetObject.GetNamedNumber("latitude")
                dLon = oVal.GetObject.GetNamedNumber("longitude")
                If sName.Length > 2 Then ' - potencjalne uciecie kilku nazw dziwnych, jak "PT"
                    Add(sCat,  ' zawsze bedzie "tram", wiec moze pomijac?
                        dLat,
                       dLon,
                        sName, sShortName)
                End If
            Next
        Catch ex As Exception
            bError = True
        End Try
        If bError Then
            App.DialogBox("ERROR: at JSON converting")
            Return False
        End If

        Await Save()    ' teoretycznie mogloby byc bez Await, zeby sobie w tle robil Save
        App.SetSettingsInt("LastLoadStops", CInt(Date.Now.ToString("yyMMdd")))

        Return True
    End Function

    Public Async Function LoadOrImport(bForceLoad As Boolean) As Task

        Dim iHowOld As Integer
        Try ' 20171108: czasem przy starcie wylatuje, może tu?
            iHowOld = CInt(Date.Now.ToString("yyMMdd")) - App.GetSettingsInt("LastLoadStops")
        Catch ex As Exception
            iHowOld = 99
        End Try

        Dim bReaded As Boolean = False
        If Not bForceLoad Then Await Load()  ' True gdy udane wczytanie; nie ma sensu czytac gdy wymuszamy import

        If Not bForceLoad Then
            If bReaded And iHowOld < 30 Then Return
        End If

        Await Import()

    End Function

    Public Function GetList() As ICollection(Of Przystanek)
        Return Itemy
    End Function
End Class
