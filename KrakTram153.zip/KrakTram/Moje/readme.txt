getbinhttp "http://www.ttss.krakow.pl/internetservice/geoserviceDispatcher/services/stopinfo/stops?left=-648000000&bottom=-324000000&right=648000000&top=324000000" przyst.txt

left=-648000000&
bottom=-324000000&
right=648000000&
top=324000000" przyst.txt


Aska:
19.9186
50.0536

236 Salwator
266 Komorowskiego


Ja:
19.97842
50.01992

178 Dauna
411 Biezanowska




Widok ~500
Franciszkanska ~500
Bernardynska ~200
GIS
Klimek

Powinny wystarczyc 4 pozycje po przecinki (1� na rowniku ma 112 km, czyli 0.0001 to 11 m, a SQRT(2)*11m to 16 m - przek�tna)
